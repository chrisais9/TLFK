package com.example.tlfk;

public class LightInfoResponse {

    private int x;
    private int y;
    private int di;
    private int time;

    public int getX(){
        return x;
    }

    public int getY(){
        return y;
    }
    public int getDi(){
        return di;
    }
    public int getTime(){
        return time;
    }
}
