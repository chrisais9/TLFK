from django.apps import AppConfig


class TrafficlightapiConfig(AppConfig):
    name = 'TrafficLightAPI'
